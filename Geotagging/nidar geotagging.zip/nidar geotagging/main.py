import cv2
import numpy as np
from ultralytics import YOLO
from geo_projection import geolocate_target_from_pixel
from telemetry import telemetry, telemetry_lock
from math import sqrt

# Camera intrinsics which we have to find
fx, fy, cx, cy = 900.0, 900.0, 640.0, 360.0
K = (fx, fy, cx, cy)

# Camera to body rotation (45° between forward & down)
R_cam_to_body = np.array([
    [0.0,         -sqrt(2)/2,  sqrt(2)/2],
    [1.0,          0.0,        0.0       ],
    [0.0,          sqrt(2)/2,  sqrt(2)/2]
], dtype=float)


model = YOLO("best.pt")

# Camera stream
cap = cv2.VideoCapture(0)  # adjust as needed

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # 1) Run YOLO
    results = model(frame)
    boxes = results[0].boxes  # ultralytics Boxes object

    # snapshot telemetry (no partial reads)
    with telemetry_lock:
        telem_snapshot = telemetry.copy()

    # 2) For each detection
    if boxes is not None:
        for box in boxes:
            # xyxy, cls, conf are tensors -> convert to Python types
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            cls_id = int(box.cls[0].item())
            conf = float(box.conf[0].item())

            # keep only 'person' class (assuming class 0 is person)
            if cls_id != 0:
                continue

            u = 0.5 * (x1 + x2)
            v = 0.5 * (y1 + y2)

            geo = geolocate_target_from_pixel(u, v, K, R_cam_to_body, telem_snapshot)
            if geo is None:
                continue

            lat_t, lon_t = geo
            print(f"Human at approx lat={lat_t:.7f}, lon={lon_t:.7f}, conf={conf:.2f}")

            # draw on frame
            cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
            cv2.circle(frame, (int(u), int(v)), 5, (0, 255, 0), -1)
            cv2.putText(frame, f"{lat_t:.5f},{lon_t:.5f}",
                        (int(u), int(v) - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)

    cv2.imshow("frame", frame)
    if cv2.waitKey(1) & 0xFF == 27:  # ESC
        break

cap.release()
cv2.destroyAllWindows()
